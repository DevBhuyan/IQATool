input_name ='D:\JRF\RetinexExp\DIP+RetinexDIP\deep-image-prior-pytorch\Retinex_inputs\synthetic.png'  
filename = 'D:\JRF\RetinexExp\DIP+RetinexDIP\deep-image-prior-pytorch\Retinex_inputs\synthetic.png';
orig_img = imread(input_name);
img = imread(filename);
figure(1), imshow(img);

% use mouse button to zoom in or out
% Press Enter to get out of the zoom mode
%zoom on;
%zoom on;
%pause() % you can zoom with your mouse and when your image is okay, you press any key
%zoom off; % to escape the zoom mode
p = ginput(2) ; 
sp(1) = min(floor(p(1)), floor(p(2))); %xmin
sp(2) = min(floor(p(3)), floor(p(4))); %ymin
sp(3) = max(ceil(p(1)), ceil(p(2)));   %xmax
sp(4) = max(ceil(p(3)), ceil(p(4)));   %ymax
% Index into the original image to create the new image
MM = img(sp(2):sp(4), sp(1): sp(3),:);
NN = orig_img(sp(2):sp(4),sp(1):sp(3),:);
%Display the subsetted image with appropriate axis ratio
figure(2); image(MM); axis image
imshow(MM);
calculate_enl(MM,filename);
%calculate_cnr(MM,NN,filename);


 function enl= calculate_enl(R1,filename)
    R1=double(R1(:));
    %R1=(R1-min(R1(:)))/(max(R1(:))-min(R1(:)))
    %R1 = im2double(R1);
    m=mean(R1);
    enl=(mean(R1)^2)/(std(R1)^2)
    fprintf('%s%f\n',filename,enl,m);
 end
 function cnr= calculate_cnr(noisy_R1,rest_R1,filename)
    r1=double(noisy_R1(:));
    r2 = double(rest_R1(:));
    %r1 (noisy_R1-min(noisy_R1(:)))/(max(noisy_R1(:))-min(noisy_R1(:)))
    %r2 = (rest_R1-min(rest_R1(:)))/(max(rest_R1(:))-min(rest_R1(:)))
    %r1 = im2double(noisy_R1)
    %r2 = im2double(rest_R1)
    cnr=abs(mean(r1)-mean(r2))/sqrt((std(r1)^2)+(std(r2)^2)+0.000001)
    fprintf('%s%f\n',filename,cnr);

 end
 