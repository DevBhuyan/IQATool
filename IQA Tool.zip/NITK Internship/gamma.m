function [] = GAMMA()
